A Pen created at CodePen.io. You can find this one at https://codepen.io/mmil/pen/lxvhu.

 Responsive Timeline built with Bootstrap

Forked from [Jennifer Perrin](http://codepen.io/jenniferperrin/)'s Pen [Super Simple Bootstrap Responsive Timeline](http://codepen.io/jenniferperrin/pen/xfwab/).