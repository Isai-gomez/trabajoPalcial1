A Pen created at CodePen.io. You can find this one at https://codepen.io/webrav/pen/PzPxez.

 This is simple HTML5 One Page Template.  Gives a different section and menu links goes straight to it. 